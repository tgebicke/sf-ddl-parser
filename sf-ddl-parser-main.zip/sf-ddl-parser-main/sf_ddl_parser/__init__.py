"""Snowflake DDL Parser - Pull and parse database DDL into organized folder structure."""

