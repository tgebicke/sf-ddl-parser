# Snowflake DDL Parser

A CLI tool that extracts DDL from Snowflake databases and parses it into an organized folder structure mirroring the Snowflake UI.

## Features

- Pull complete database DDL from Snowflake using `GET_DDL()`
- Parse DDL into organized folder structure by schema and object type
- Automatic change detection - only re-parses when DDL changes
- Configurable schema exclusions
- Automatic backup of previous DDL dumps
- Support for multiple authentication methods (password, Okta SSO)

## Installation

```bash
cd app
poetry install
```

## Configuration

Copy `config.sample.json` to `config.json` and update with your settings:

```bash
cp config.sample.json config.json
```

Configuration options:

```json
{
  "account": "your-account-identifier",
  "user": "YOUR_USERNAME",
  "warehouse": "COMPUTE_WH",
  "database": "YOUR_DATABASE",
  "role": "YOUR_ROLE",
  "auth_method": "password",
  "password": "your_password",
  "sql_file": "../full_db/fulldb.sql",
  "output_dir": "../databases",
  "backup_dir": "../backups",
  "database_name_override": null,
  "exclude_schemas": ["INFORMATION_SCHEMA", "PUBLIC"]
}
```

### Configuration Options

| Option | Description | Default |
|--------|-------------|---------|
| `account` | Snowflake account identifier (org-account format) | Required |
| `user` | Snowflake username | Required |
| `warehouse` | Snowflake warehouse | Required |
| `database` | Database to extract DDL from | Required |
| `role` | Snowflake role to use | Required |
| `auth_method` | Authentication method: `password` or `okta` | `password` |
| `password` | Password (for password auth) | - |
| `okta_url` | Okta SSO URL (for okta auth) | - |
| `sql_file` | Path to save the DDL dump | `full_db/fulldb.sql` |
| `output_dir` | Directory for parsed structure | `databases` |
| `backup_dir` | Directory for DDL backups | `backups` |
| `database_name_override` | Override auto-detected database name | `null` |
| `exclude_schemas` | Array of schema names to skip | `[]` |

## Usage

### Basic Usage

```bash
# Pull DDL from Snowflake and parse it
poetry run sf-parser

# Use a custom config file
poetry run sf-parser --config my_config.json
```

### CLI Options

| Flag | Description |
|------|-------------|
| `--config FILE` | Path to configuration file (default: `config.json`) |
| `--no-pull` | Skip pulling from Snowflake, use existing DDL file |
| `--force-parse` | Force parsing even if DDL hasn't changed |

### Examples

```bash
# Re-parse existing DDL without connecting to Snowflake
poetry run sf-parser --no-pull --force-parse

# Force a fresh parse even if no changes detected
poetry run sf-parser --force-parse
```

## Output Structure

The parser creates a folder structure organized by schema and object type:

```
databases/
└── YOUR_DATABASE/
    ├── SCHEMA_ONE/
    │   ├── schemas/
    │   │   └── SCHEMA_ONE.sql
    │   ├── tables/
    │   │   ├── TABLE_A.sql
    │   │   └── TABLE_B.sql
    │   ├── views/
    │   │   └── VIEW_A.sql
    │   ├── procedures/
    │   │   └── PROC_A.sql
    │   └── functions/
    │       └── FUNC_A.sql
    └── SCHEMA_TWO/
        └── ...
```

### Supported Object Types

- Tables (including transient, temporary, external)
- Views (including secure, materialized)
- Procedures
- Functions
- Sequences
- Streams
- Pipes
- Tasks
- Stages
- File Formats
- And more...

## Authentication

### Password Authentication

Set `auth_method` to `password` and provide your password:

```json
{
  "auth_method": "password",
  "password": "your_password"
}
```

### Okta SSO Authentication

Set `auth_method` to `okta` and provide your Okta URL:

```json
{
  "auth_method": "okta",
  "okta_url": "https://yourorg.okta.com"
}
```

A browser window will open for authentication.

## Security Note

Keep your `config.json` file secure and add it to `.gitignore` to avoid committing credentials to version control.

